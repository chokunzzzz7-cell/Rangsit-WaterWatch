using System.Drawing;
using System.Globalization;

namespace RangsitMonitor;

public class MainForm : Form
{
    static readonly Dictionary<string, Color> LevelColors = new()
    {
        ["green"]  = Color.FromArgb(0x5f, 0x8a, 0x3a),
        ["yellow"] = Color.FromArgb(0xe8, 0xb9, 0x1c),
        ["orange"] = Color.FromArgb(0xc9, 0x58, 0x2a),
        ["red"]    = Color.FromArgb(0xc4, 0x20, 0x2a),
    };

    readonly LevelReader reader;
    readonly System.Windows.Forms.Timer timer = new() { Interval = 5 * 60 * 1000 };
    readonly System.Windows.Forms.Timer clock = new() { Interval = 30 * 1000 };

    readonly Label warning = new();
    readonly Panel hero = new();
    readonly Label nameLabel = new();
    readonly Label thaiLabel = new();
    readonly Label whenLabel = new();
    readonly Panel strip = new();
    readonly Label fractionsLabel = new();
    readonly PictureBox preview = new();
    readonly Button checkBtn = new();
    readonly Button debugBtn = new();
    readonly Button fileBtn = new();
    readonly CheckBox autoBox = new();
    readonly LinkLabel cameraLink = new();

    Status status = new();
    bool busy;

    public MainForm()
    {
        reader = new LevelReader(AppContext.BaseDirectory);

        Text = "Rangsit water level";
        ClientSize = new Size(760, 720);
        MinimumSize = new Size(560, 640);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10f);
        BackColor = Color.FromArgb(0xee, 0xf1, 0xec);

        BuildUi();

        timer.Tick += async (_, _) => await RunCheck();
        clock.Tick += (_, _) => Redraw();
        autoBox.CheckedChanged += (_, _) => timer.Enabled = autoBox.Checked;
        checkBtn.Click += async (_, _) => await RunCheck();
        debugBtn.Click += async (_, _) => await ShowDebug(null);
        fileBtn.Click += async (_, _) => await PickFile();
        cameraLink.LinkClicked += (_, _) => OpenUrl(reader.Cfg.CameraPage);

        Load += async (_, _) =>
        {
            status = reader.LoadStatus();
            Redraw();
            clock.Start();
            timer.Start();
            await RunCheck();
        };
    }

    void BuildUi()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill, ColumnCount = 1, Padding = new Padding(16), AutoScroll = true,
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        var title = new Label
        {
            Text = "Rangsit water level", AutoSize = true,
            Font = new Font(Font.FontFamily, 16f, FontStyle.Bold), Margin = new Padding(0, 0, 0, 8),
        };

        warning.AutoSize = false; warning.Height = 38; warning.Dock = DockStyle.Top;
        warning.BackColor = LevelColors["orange"]; warning.ForeColor = Color.White;
        warning.TextAlign = ContentAlignment.MiddleLeft; warning.Padding = new Padding(10, 0, 0, 0);
        warning.Visible = false; warning.Margin = new Padding(0, 0, 0, 10);

        // big coloured status box
        hero.Dock = DockStyle.Top; hero.Height = 150; hero.Padding = new Padding(18, 14, 18, 10);
        hero.BackColor = Color.FromArgb(0x5d, 0x6d, 0x64); hero.Margin = new Padding(0, 0, 0, 12);
        nameLabel.Font = new Font(Font.FontFamily, 30f, FontStyle.Bold);
        nameLabel.AutoSize = true; nameLabel.Text = "Loading…"; nameLabel.ForeColor = Color.White;
        nameLabel.Location = new Point(14, 8);
        thaiLabel.Font = new Font("Segoe UI", 14f); thaiLabel.AutoSize = true; thaiLabel.ForeColor = Color.White;
        thaiLabel.Location = new Point(18, 72);
        whenLabel.AutoSize = true; whenLabel.ForeColor = Color.White; whenLabel.Location = new Point(18, 108);
        hero.Controls.AddRange(new Control[] { nameLabel, thaiLabel, whenLabel });

        // 24h history strip (one block per check)
        var stripCard = Card(110);
        var stripTitle = new Label { Text = "Last 24 hours", AutoSize = true, Font = new Font(Font, FontStyle.Bold), Location = new Point(12, 8) };
        strip.Location = new Point(12, 36); strip.Height = 26; strip.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
        strip.Width = stripCard.Width - 24;
        strip.Paint += PaintStrip;
        var stripNote = new Label
        {
            Text = "One block per 5-minute check, oldest on the left.", AutoSize = true,
            ForeColor = Color.FromArgb(0x5d, 0x6d, 0x64), Location = new Point(12, 70),
        };
        stripCard.Controls.AddRange(new Control[] { stripTitle, strip, stripNote });
        stripCard.Resize += (_, _) => strip.Width = stripCard.Width - 24;

        // controls
        var ctlCard = Card(92);
        checkBtn.Text = "Check now"; checkBtn.Location = new Point(12, 12); checkBtn.Size = new Size(110, 32);
        debugBtn.Text = "Show boxes"; debugBtn.Location = new Point(130, 12); debugBtn.Size = new Size(110, 32);
        fileBtn.Text = "Test file…"; fileBtn.Location = new Point(248, 12); fileBtn.Size = new Size(110, 32);
        autoBox.Text = "Auto-check every 5 min"; autoBox.Checked = true; autoBox.AutoSize = true;
        autoBox.Location = new Point(372, 18);
        cameraLink.Text = "Open the live camera"; cameraLink.AutoSize = true; cameraLink.Location = new Point(12, 56);
        ctlCard.Controls.AddRange(new Control[] { checkBtn, debugBtn, fileBtn, autoBox, cameraLink });

        fractionsLabel.AutoSize = true; fractionsLabel.ForeColor = Color.FromArgb(0x5d, 0x6d, 0x64);
        fractionsLabel.Margin = new Padding(2, 0, 0, 8);

        preview.Dock = DockStyle.Top; preview.Height = 200; preview.SizeMode = PictureBoxSizeMode.Zoom;
        preview.BackColor = Color.FromArgb(0xd3, 0xda, 0xd2); preview.Margin = new Padding(0);

        var note = new Label
        {
            Text = "The level is read automatically from the camera picture, so treat it as an estimate.",
            AutoSize = true, ForeColor = Color.FromArgb(0x5d, 0x6d, 0x64), Margin = new Padding(2, 8, 0, 0),
        };

        foreach (var c in new Control[] { title, warning, hero, stripCard, ctlCard, fractionsLabel, preview, note })
        {
            c.Dock = c is Label { AutoSize: true } ? DockStyle.None : DockStyle.Top;
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.Controls.Add(c);
        }
        Controls.Add(root);
    }

    static Panel Card(int height) => new()
    {
        Height = height, Dock = DockStyle.Top, BackColor = Color.White,
        BorderStyle = BorderStyle.FixedSingle, Margin = new Padding(0, 0, 0, 12),
    };

    // ---------- actions ----------

    async Task RunCheck()
    {
        if (busy) return;
        busy = true; checkBtn.Enabled = false; checkBtn.Text = "Checking…";
        try
        {
            status = await reader.CheckAsync();
            Redraw();
            await ShowDebug(null, quiet: true);
        }
        finally { busy = false; checkBtn.Enabled = true; checkBtn.Text = "Check now"; }
    }

    async Task PickFile()
    {
        using var dlg = new OpenFileDialog { Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp", Title = "Pick a saved screenshot" };
        if (dlg.ShowDialog(this) == DialogResult.OK) await ShowDebug(dlg.FileName);
    }

    /// <summary>Draws the white boxes on the image (like --debug) so you can calibrate config.json.</summary>
    async Task ShowDebug(string? file, bool quiet = false)
    {
        try
        {
            using var img = await reader.LoadImageAsync(file);
            var (level, fr) = reader.ReadLevel(img);
            var drawn = reader.DrawDebug(img);
            preview.Image?.Dispose();
            preview.Image = drawn;
            drawn.Save(Path.Combine(AppContext.BaseDirectory, "debug.jpg"));
            if (!quiet)
                fractionsLabel.Text = $"level: {level}   visible: " +
                    string.Join(", ", fr.Select(kv => $"{kv.Key} {kv.Value:0.00}")) +
                    $"   brightness: {Math.Round(LevelReader.Brightness(img))}";
        }
        catch (Exception e)
        {
            if (!quiet) MessageBox.Show(this, e.Message, "Could not load the picture");
        }
    }

    static void OpenUrl(string url) =>
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url) { UseShellExecute = true });

    // ---------- drawing ----------

    static string Ago(DateTime t)
    {
        int m = (int)Math.Round((DateTime.UtcNow - t).TotalMinutes);
        return m < 1 ? "just now" : m < 60 ? $"{m} min ago" : $"{Math.Round(m / 60.0)} h ago";
    }

    static DateTime? Parse(string? s) =>
        DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out var d)
            ? d : null;

    void Redraw()
    {
        string? lv = status.Level;
        if (lv != null && LevelReader.Labels.TryGetValue(lv, out var lbl))
        {
            hero.BackColor = LevelColors[lv];
            Color fg = lv == "yellow" ? Color.FromArgb(0x2a, 0x22, 0x00) : Color.White;
            nameLabel.ForeColor = thaiLabel.ForeColor = whenLabel.ForeColor = fg;
            nameLabel.Text = lbl.En; thaiLabel.Text = lbl.Th;
        }
        else { nameLabel.Text = "No reading yet"; thaiLabel.Text = ""; }

        var checkedAt = Parse(status.CheckedAt);
        whenLabel.Text = checkedAt.HasValue ? "Checked " + Ago(checkedAt.Value) : "";

        bool old = checkedAt.HasValue && (DateTime.UtcNow - checkedAt.Value).TotalMinutes > 20;
        if (old || !status.Ok)
        {
            warning.Visible = true;
            warning.Text = old
                ? "Data is more than 20 minutes old. Check the camera directly."
                : (string.IsNullOrEmpty(status.Note) ? "The last check failed." : status.Note);
        }
        else warning.Visible = false;

        strip.Invalidate();
    }

    void PaintStrip(object? sender, PaintEventArgs e)
    {
        const int total = 288;
        float w = (float)strip.Width / total;
        var hist = status.History.TakeLast(total).ToList();
        int offset = total - hist.Count;
        using var empty = new SolidBrush(Color.FromArgb(0xd3, 0xda, 0xd2));
        for (int i = 0; i < total; i++)
        {
            Brush b = empty; SolidBrush? own = null;
            if (i >= offset && LevelColors.TryGetValue(hist[i - offset].Level, out var c))
                b = own = new SolidBrush(c);
            e.Graphics.FillRectangle(b, i * w, 0, Math.Max(1f, w - 1f), strip.Height);
            own?.Dispose();
        }
    }
}
