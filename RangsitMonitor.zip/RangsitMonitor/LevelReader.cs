using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Net.Http;
using System.Text.Json;

namespace RangsitMonitor;

/// <summary>C# port of monitor.py: reads the camera snapshot and works out the water level.</summary>
public class LevelReader
{
    public static readonly Dictionary<string, (string En, string Th)> Labels = new()
    {
        ["green"]  = ("Normal",   "ปกติ"),
        ["yellow"] = ("Warning",  "เฝ้าระวัง"),
        ["orange"] = ("High",     "ระดับสูง เตรียมพร้อม"),
        ["red"]    = ("Critical", "วิกฤต"),
    };

    static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(30) };
    static readonly JsonSerializerOptions JsonOpts = new() { WriteIndented = true };

    public Config Cfg { get; }
    readonly string statusPath;

    public LevelReader(string baseDir)
    {
        Cfg = JsonSerializer.Deserialize<Config>(File.ReadAllText(Path.Combine(baseDir, "config.json")))
              ?? throw new InvalidOperationException("config.json is empty");
        statusPath = Path.Combine(baseDir, "status.json");
    }

    // ---------- image helpers ----------

    public async Task<Bitmap> LoadImageAsync(string? path = null)
    {
        if (path != null)
            return new Bitmap(new MemoryStream(await File.ReadAllBytesAsync(path)));

        using var req = new HttpRequestMessage(HttpMethod.Get, Cfg.SnapshotUrl);
        req.Headers.TryAddWithoutValidation("User-Agent", "Mozilla/5.0");
        req.Headers.TryAddWithoutValidation("Referer", Cfg.CameraPage);
        using var res = await Http.SendAsync(req);
        res.EnsureSuccessStatusCode();
        return new Bitmap(new MemoryStream(await res.Content.ReadAsByteArrayAsync()));
    }

    Rectangle Scaled(int[] box, Bitmap img)
    {
        double k = (double)img.Width / Cfg.RefWidth;
        int x1 = (int)(box[0] * k), y1 = (int)(box[1] * k);
        int x2 = (int)(box[2] * k), y2 = (int)(box[3] * k);
        return Rectangle.Intersect(new Rectangle(x1, y1, x2 - x1, y2 - y1),
                                   new Rectangle(0, 0, img.Width, img.Height));
    }

    static Bitmap Resize(Bitmap src, Rectangle area, int w, int h)
    {
        var dst = new Bitmap(w, h, PixelFormat.Format24bppRgb);
        using var g = Graphics.FromImage(dst);
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.DrawImage(src, new Rectangle(0, 0, w, h), area, GraphicsUnit.Pixel);
        return dst;
    }

    static (double h, double s, double v) ToHsv(Color c)
    {
        double r = c.R / 255.0, g = c.G / 255.0, b = c.B / 255.0;
        double max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
        double d = max - min, h = 0;
        if (d > 0)
        {
            if (max == r) h = ((g - b) / d) % 6;
            else if (max == g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h *= 60;
            if (h < 0) h += 360;
        }
        double s = max == 0 ? 0 : d / max;
        return (h, s, max);
    }

    double Fraction(Bitmap img, Band band)
    {
        var area = Scaled(band.Box, img);
        if (area.Width <= 0 || area.Height <= 0) return 0;
        using var crop = Resize(img, area, 40, 40);
        int ok = 0;
        for (int y = 0; y < 40; y++)
            for (int x = 0; x < 40; x++)
            {
                var (h, s, v) = ToHsv(crop.GetPixel(x, y));
                if (s >= band.Sat && v >= band.Val && band.Hue.Any(r => h >= r[0] && h <= r[1]))
                    ok++;
            }
        return ok / 1600.0;
    }

    public (string level, Dictionary<string, double> fractions) ReadLevel(Bitmap img)
    {
        var fr = Cfg.Bands.ToDictionary(kv => kv.Key, kv => Math.Round(Fraction(img, kv.Value), 2));
        var hidden = fr.Where(kv => kv.Value < Cfg.MinFraction).Select(kv => kv.Key).ToHashSet();
        // the highest band that is no longer visible is where the water is
        foreach (var name in new[] { "red", "orange", "yellow" })
            if (hidden.Contains(name)) return (name, fr);
        return ("green", fr);
    }

    public static double Brightness(Bitmap img)
    {
        using var small = Resize(img, new Rectangle(0, 0, img.Width, img.Height), 32, 18);
        double sum = 0;
        for (int y = 0; y < 18; y++)
            for (int x = 0; x < 32; x++)
            {
                var c = small.GetPixel(x, y);
                sum += 0.299 * c.R + 0.587 * c.G + 0.114 * c.B;
            }
        return sum / (32 * 18);
    }

    /// <summary>Same as "monitor.py --debug": returns a copy with the band boxes drawn on it.</summary>
    public Bitmap DrawDebug(Bitmap img)
    {
        var copy = new Bitmap(img);
        using var g = Graphics.FromImage(copy);
        using var pen = new Pen(Color.White, 3);
        foreach (var b in Cfg.Bands.Values) g.DrawRectangle(pen, Scaled(b.Box, copy));
        return copy;
    }

    // ---------- status file ----------

    public Status LoadStatus()
    {
        try { return JsonSerializer.Deserialize<Status>(File.ReadAllText(statusPath)) ?? new Status(); }
        catch { return new Status { Note = "Waiting for the first check" }; }
    }

    void SaveStatus(Status st) => File.WriteAllText(statusPath, JsonSerializer.Serialize(st, JsonOpts));

    // ---------- one full check (same logic as main() in monitor.py) ----------

    public async Task<Status> CheckAsync(string? file = null)
    {
        var st = LoadStatus();
        string now = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'+00:00'");

        Bitmap img;
        try { img = await LoadImageAsync(file); }
        catch (Exception e)
        {
            // camera unreachable: record it, keep the last known level
            st.Ok = false; st.Note = $"Camera error: {e.Message}"; st.CheckedAt = now;
            SaveStatus(st);
            return st;
        }

        using (img)
        {
            try
            {
                st.Ok = true;
                if (Brightness(img) < Cfg.NightMinBrightness)
                {
                    st.Ok = false; st.Note = "Image too dark to read"; st.CheckedAt = now;
                }
                else
                {
                    var (level, fr) = ReadLevel(img);
                    string? confirmed = st.Level;

                    // a new level must be seen on two runs in a row before it counts
                    if (level == confirmed) st.Pending = null;
                    else if (st.Pending == level || confirmed == null)
                    {
                        st.Level = level; st.Pending = null; st.ChangedAt = now;
                        if (confirmed != null)
                            await NotifyAsync($"Rangsit water level: {Labels[level].En} ({level})");
                    }
                    else st.Pending = level;

                    st.CheckedAt = now; st.Fractions = fr; st.Note = "";
                    st.History.Add(new HistoryEntry { T = now, Level = st.Level ?? level });
                    if (st.History.Count > 288) st.History = st.History.TakeLast(288).ToList();
                }
            }
            catch (Exception e)
            {
                st.Ok = false; st.Note = $"Error: {e.Message}"; st.CheckedAt = now;
            }
        }

        SaveStatus(st);
        return st;
    }

    // ---------- Telegram (optional) ----------

    static async Task NotifyAsync(string text)
    {
        string? token = Environment.GetEnvironmentVariable("TELEGRAM_TOKEN");
        string? chat = Environment.GetEnvironmentVariable("TELEGRAM_CHAT_ID");
        if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(chat)) return;
        try
        {
            using var body = new FormUrlEncodedContent(new Dictionary<string, string>
                { ["chat_id"] = chat, ["text"] = text });
            await Http.PostAsync($"https://api.telegram.org/bot{token}/sendMessage", body);
        }
        catch (Exception e) { Console.WriteLine("telegram failed: " + e.Message); }
    }
}
