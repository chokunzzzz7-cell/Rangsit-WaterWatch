# Rangsit water level - C# Windows Forms version

Port of `monitor.py` + `index.html` to a .NET 8 Windows Forms app.

## Build / run
Needs the .NET 8 SDK on Windows.

    dotnet run

or `dotnet publish -c Release -r win-x64 --self-contained` for a single folder you can copy anywhere.

## What it does
- Downloads the camera snapshot every 5 minutes (and on "Check now").
- Same detection logic as the Python version: it looks at the red / orange / yellow
  bands of the gauge board and reports the highest band that is no longer visible.
- A new level must be seen on two checks in a row before it is accepted.
- Writes `status.json` (same format as before) and keeps 24 hours of history.
- Optional Telegram alerts: set the environment variables `TELEGRAM_TOKEN` and `TELEGRAM_CHAT_ID`.

## Calibrating
Press **Show boxes** (or **Test file…** with a saved screenshot). The white rectangles must sit on
the red, orange and yellow parts of the board. If not, edit the `box` values in `config.json`.
The marked image is also saved as `debug.jpg`.
