using System.Text.Json.Serialization;

namespace RangsitMonitor;

public class Band
{
    [JsonPropertyName("box")] public int[] Box { get; set; } = new int[4];
    [JsonPropertyName("hue")] public double[][] Hue { get; set; } = Array.Empty<double[]>();
    [JsonPropertyName("sat")] public double Sat { get; set; }
    [JsonPropertyName("val")] public double Val { get; set; }
}

public class Config
{
    [JsonPropertyName("camera_page")] public string CameraPage { get; set; } = "";
    [JsonPropertyName("snapshot_url")] public string SnapshotUrl { get; set; } = "";
    [JsonPropertyName("ref_width")] public int RefWidth { get; set; } = 1920;
    [JsonPropertyName("night_min_brightness")] public double NightMinBrightness { get; set; } = 45;
    [JsonPropertyName("min_fraction")] public double MinFraction { get; set; } = 0.35;
    [JsonPropertyName("bands")] public Dictionary<string, Band> Bands { get; set; } = new();
}

public class HistoryEntry
{
    [JsonPropertyName("t")] public string T { get; set; } = "";
    [JsonPropertyName("level")] public string Level { get; set; } = "";
}

// Same layout as the old status.json, so the web page (index.html) still works with it.
public class Status
{
    [JsonPropertyName("ok")] public bool Ok { get; set; }
    [JsonPropertyName("note")] public string Note { get; set; } = "";
    [JsonPropertyName("level")] public string? Level { get; set; }
    [JsonPropertyName("pending")] public string? Pending { get; set; }
    [JsonPropertyName("changed_at")] public string? ChangedAt { get; set; }
    [JsonPropertyName("checked_at")] public string? CheckedAt { get; set; }
    [JsonPropertyName("fractions")] public Dictionary<string, double>? Fractions { get; set; }
    [JsonPropertyName("history")] public List<HistoryEntry> History { get; set; } = new();
}
